# neutrosopy
Class and utility functions for neutrosophic numbers.
